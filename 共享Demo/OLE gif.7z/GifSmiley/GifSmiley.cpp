// GifSmiley.cpp : Implementation of DLL Exports.


#include "stdafx.h"
#include "resource.h"


// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{AFA51984-FE21-4725-BE31-D16F4EBD0C89}", 
		 name = "GifSmiley", 
		 helpstring = "GifSmiley 1.0 Type Library",
		 resource_name = "IDR_GIFSMILEY") ]
class CGifSmileyModule
{
public:
// Override CAtlDllModuleT members
};
		 
